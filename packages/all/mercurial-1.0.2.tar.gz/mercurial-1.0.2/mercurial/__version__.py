# This file is auto-generated.
version = '1.0.2'
